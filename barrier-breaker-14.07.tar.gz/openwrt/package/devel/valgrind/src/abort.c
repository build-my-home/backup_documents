void abort(void)
{
}
